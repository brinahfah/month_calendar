<?php
echo "TEST OK - " . date("H:i:s");
?>